# app/__init__.py

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

# 1. Crie as instâncias das extensões AQUI, fora da função
db = SQLAlchemy()
login_manager = LoginManager()

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'chave-super-secreta-mude-depois'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///cuidadoras.db'

    # 2. Inicialize as extensões com o app DENTRO da função
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'main.login' # Para onde redirecionar se não estiver logado

    # 3. Importe seus modelos e rotas AQUI, DENTRO da função
    from .models import Usuario
    from .routes import main_blueprint # Mudei o nome para evitar conflito

    # 4. Registre o Blueprint
    app.register_blueprint(main_blueprint)

    # 5. Configure o user_loader do Flask-Login
    @login_manager.user_loader
    def load_user(user_id):
        # Ele precisa saber como encontrar um usuário pelo ID
        return Usuario.query.get(int(user_id))

    return app