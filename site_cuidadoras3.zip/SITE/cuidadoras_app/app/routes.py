# app/routes.py

from flask import Blueprint, render_template, request, redirect, url_for, flash
from .models import Usuario
from . import db
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, login_required, logout_user, current_user

main_blueprint = Blueprint('main', __name__)

@main_blueprint.route('/')
def index():
    return render_template('index.html')

@main_blueprint.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        email = request.form.get('email')
        usuario_existente = Usuario.query.filter_by(email=email).first()

        if usuario_existente:
            flash('Este email já está cadastrado. Tente fazer login.')
            return redirect(url_for('main.login'))

        nome = request.form.get('nome')
        # Criptografa a senha antes de salvar!
        senha = generate_password_hash(request.form.get('senha'), method='pbkdf2:sha256')
        tipo = request.form.get('tipo')

        novo_usuario = Usuario(nome=nome, email=email, senha=senha, tipo=tipo)
        db.session.add(novo_usuario)
        db.session.commit()

        flash('Cadastro realizado com sucesso! Faça o login.')
        return redirect(url_for('main.login'))
        
    return render_template('cadastro.html')


@main_blueprint.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        senha = request.form.get('senha')
        usuario = Usuario.query.filter_by(email=email).first()

        # Verifica se o usuário existe E se a senha está correta
        if usuario and check_password_hash(usuario.senha, senha):
            login_user(usuario)
            return redirect(url_for('main.perfil'))
        else:
            flash('Login inválido. Verifique seu email e senha.')
            return redirect(url_for('main.login'))

    return render_template('login.html')

@main_blueprint.route('/perfil')
@login_required
def perfil():
    # O current_user já está disponível no template graças ao Flask-Login
    return render_template('perfil.html')

@main_blueprint.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.index'))


