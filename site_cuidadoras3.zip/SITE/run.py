import os
from cuidadoras_app.app import create_app, db


# run.py




app = create_app()

# Este código cria o banco de dados se o arquivo ainda não existir
@app.before_request
def create_tables():
    if not os.path.exists(os.path.join('instance', 'cuidadoras.db')):
        with app.app_context():
            db.create_all()
            print("Banco de dados criado!")

if __name__ == '__main__':
    app.run(debug=True)