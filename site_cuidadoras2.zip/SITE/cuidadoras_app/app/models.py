# app/models.py

from . import db
from flask_login import UserMixin

# UserMixin é essencial para o Flask-Login funcionar
class Usuario(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    senha = db.Column(db.String(150), nullable=False)
    tipo = db.Column(db.String(20), nullable=False) # "cuidadora" ou "admin"